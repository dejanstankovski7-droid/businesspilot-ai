const express = require('express');
const path = require('path');
const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));
const generate = require('./netlify/functions/generate').handler;
app.post('/api/generate', async (req, res) => {
  const result = await generate({ httpMethod: 'POST', body: JSON.stringify(req.body || {}) });
  res.status(result.statusCode).type('application/json').send(result.body);
});
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`BusinessPilot AI running on ${port}`));
