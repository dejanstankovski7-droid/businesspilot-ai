# BusinessPilot AI — Netlify-ready update

This project contains six AI tools: Business Plan, Website Builder, Marketing Assistant, Social Media, Business Advisor, and Financial Planner. All six use a server-side OpenAI Responses API call. The Website Builder asks the model for a complete HTML page and displays it in an isolated preview iframe.

## Deploy to Netlify
1. Upload/deploy this project folder or ZIP to your Netlify site. The publish directory is `public`; the serverless function is in `netlify/functions`.
2. In Netlify, open **Site configuration → Environment variables** and add `OPENAI_API_KEY` with your own OpenAI API key. Optionally add `OPENAI_MODEL` (default `gpt-4.1-mini`).
3. Trigger a fresh deploy after adding the environment variable.
4. Test each of the six tools.

The API key must remain a Netlify environment variable. Do not put it in `public/index.html`, commit it, or share it. API usage may incur charges.

## Local run
Run `npm install`, set `OPENAI_API_KEY` in the environment, then `npm start` and open `http://localhost:3000`.

## Important scope
This update adds real AI generation endpoints and an actual HTML website preview. It does not yet include customer accounts, subscriptions, payment processing, usage quotas, saved projects, or one-click publishing of customer-generated websites. Those require additional backend and product work.
