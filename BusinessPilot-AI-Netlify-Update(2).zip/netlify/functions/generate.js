const prompts = {
  plan: `You are an experienced small-business strategist. Create a practical business plan with: executive summary, problem and solution, offer, ideal customers, market and competitors (label assumptions), pricing, marketing and sales, operations, startup costs, monthly cost estimates, risks, and a realistic 30-day launch plan. Use clear headings and concrete actions. Never invent verified market facts.`,
  website: `You are an expert web designer and front-end developer. Build a complete, attractive, responsive, single-page website for the business described by the user. Return ONLY a complete standalone HTML document (starting with <!doctype html>) with all CSS inside a <style> element and no markdown fences. Include a strong hero, navigation, relevant sections, services or menu/products, about, testimonials clearly marked as sample placeholders (never fake real reviews), FAQ, contact details as editable placeholders if not supplied, and clear calls to action. Make it look professionally designed and specific to the business. Use accessible semantic HTML, mobile responsive CSS, and no external libraries, scripts, remote assets, forms that pretend to submit, or unsupported claims. Do not include explanations outside the HTML.`,
  marketing: `You are a senior small-business marketing strategist. Create a practical marketing campaign with positioning, audience segments, customer pain points, 3 campaign concepts, ad headlines, primary ad copy, calls to action, recommended channels, a modest test budget allocation, a 2-week test schedule, and measurable KPIs. Avoid guaranteeing results.`,
  social: `You are a social media strategist. Create a useful 7-day content calendar tailored to this business. For each day include platform, format, hook, caption, call to action, and visual direction. Include suggested hashtags where relevant and keep the voice consistent with the brief.`,
  advisor: `You are a thoughtful small-business advisor. Analyze the situation, identify the main issue, list options with pros and cons, identify assumptions and risks, and finish with the three most useful next actions. Do not present legal, tax, or financial guidance as a substitute for a qualified professional.`,
  finance: `You are a small-business financial planning assistant. Build an illustrative estimate using the information supplied: startup costs, fixed monthly costs, variable costs, pricing and sales assumptions, estimated revenue, gross profit, break-even calculation, cash-flow considerations, and cost controls. Show formulas and clearly label every missing input and estimate. Never present projections as guaranteed or as professional financial/tax advice.`
};
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers: { 'Content-Type': 'application/json', 'Allow': 'POST' }, body: JSON.stringify({ error: 'Method not allowed.' }) };
  let body;
  try { body = JSON.parse(event.body || '{}'); } catch { return { statusCode: 400, body: JSON.stringify({ error: 'Invalid request. Please try again.' }) }; }
  const { tool, details } = body;
  if (!prompts[tool] || typeof details !== 'string' || details.trim().length < 8) return { statusCode: 400, body: JSON.stringify({ error: 'Choose a tool and enter at least a little detail.' }) };
  const key = process.env.OPENAI_API_KEY;
  if (!key) return { statusCode: 503, body: JSON.stringify({ error: 'The AI connection is not activated yet. The site owner must add OPENAI_API_KEY in Netlify → Site configuration → Environment variables.' }) };
  try {
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-4.1-mini', instructions: prompts[tool], input: details.trim(), max_output_tokens: tool === 'website' ? 5000 : 2600 })
    });
    const data = await response.json();
    if (!response.ok) return { statusCode: response.status, body: JSON.stringify({ error: data.error?.message || 'The AI service returned an error.' }) };
    const result = (data.output || []).flatMap(item => item.content || []).filter(item => item.type === 'output_text').map(item => item.text).join('\n').trim();
    if (!result) return { statusCode: 502, body: JSON.stringify({ error: 'The AI returned an empty result. Please try again.' }) };
    if (tool === 'website' && !/^<!doctype html/i.test(result)) return { statusCode: 502, body: JSON.stringify({ error: 'The website generator did not return a complete HTML page. Please try again.' }) };
    return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ result, type: tool === 'website' ? 'html' : 'text' }) };
  } catch (error) {
    return { statusCode: 500, body: JSON.stringify({ error: 'Could not reach the AI service. Please try again.' }) };
  }
};
